// Função scrollToTop
function scrollToTop() {
    // Rola a página para o topo de forma suave
    window.scrollTo({
        top: 0, // Define a posição de rolagem para o topo da página
        behavior: 'smooth' // Define a rolagem suave
    });
}
